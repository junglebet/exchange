<?php

return [
    'categories' => [
        ['id' => 1, 'name' => 'News'],
        ['id' => 2, 'name' => 'Announcements'],
    ]
];
