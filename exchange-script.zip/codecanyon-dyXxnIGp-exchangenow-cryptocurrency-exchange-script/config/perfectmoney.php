<?php

return [
    'login' => env('PERFECT_MONEY_LOGIN'),
    'pass' => env('PERFECT_MONEY_PASSWORD'),
    'account_id' => env('PERFECT_MONEY_ACCOUNT_ID'),
    'auto_withdrawals' => env('PERFECT_MONEY_AUTO_WITHDRAWALS'),
    'hash' => env('PERFECT_MONEY_ALT_HASH', '9bkGy1D6Dv4M8fqzWSASJCExU'),
];
