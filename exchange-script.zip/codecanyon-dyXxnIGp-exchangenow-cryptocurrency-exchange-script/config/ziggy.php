<?php

return [
    'except' => [
        'debugbar.*',
        'horizon.*',
        'ignition*',
        'coinpayments*',
        'stripe*',
        'bitcoin*',
        'bnb*',
        'ethereum*',
    ],
    /*'groups' => [
        'admin' => ['home','order*', 'reports*', 'market*','wallet*','swap','article*','page*','user*','api*','register*','password*','verification*','voucher*','user*','profile*','log*','chart'],
    ],*/
];

