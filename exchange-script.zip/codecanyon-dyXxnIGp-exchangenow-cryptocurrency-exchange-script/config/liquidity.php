<?php

return [
    'api_key' => env('BINANCE_API_KEY'),
    'api_secret' => env('BINANCE_API_SECRET'),
    'testnet' => env('BINANCE_API_TESTNET', false),
];
