<script>
import Template from '{Template}/Web/Components/HeaderCaption.template'
export default Template({
    data() {
        return {

        }
    },
    methods: {

    }
})
</script>
