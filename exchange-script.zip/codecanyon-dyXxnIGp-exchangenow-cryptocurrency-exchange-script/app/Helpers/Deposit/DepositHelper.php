<?php

const DEPOSIT_CONFIRMED = 'confirmed';
const DEPOSIT_PENDING = 'pending';
const DEPOSIT_IGNORED = 'ignored';
const DEPOSIT_INSCRIBING = 'inscribing';
const DEPOSIT_INSCRIBING_ORDERED = 'inscribing_ordered';
const DEPOSIT_INSCRIBING_FAILED = "inscribing_failed";
const DEPOSIT_INSCRIBED = 'inscribed';

const FIAT_DEPOSIT_CONFIRMED = 'confirmed';
const FIAT_DEPOSIT_PENDING = 'pending';
const FIAT_DEPOSIT_REJECTED = 'rejected';
