<?php

namespace App\Services\ColdStorage;

use App\Models\ColdStorage\ColdStorage;
use App\Services\Wallet\WalletService;

class ColdStorageService {

    public function transferCheck($network, $amount, $currency) {
        // In VIP Plan
    }
}
