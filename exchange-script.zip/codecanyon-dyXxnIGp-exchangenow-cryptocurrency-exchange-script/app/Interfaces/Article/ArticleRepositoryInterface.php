<?php

namespace App\Interfaces\Article;

interface ArticleRepositoryInterface
{

}
