<?php

namespace App\Interfaces\Withdrawal;

interface WithdrawalRepositoryInterface
{

}
