<?php

namespace App\Interfaces\Deposit;

interface DepositRepositoryInterface
{

}
